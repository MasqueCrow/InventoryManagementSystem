-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2015 at 03:22 PM
-- Server version: 5.6.15-log
-- PHP Version: 5.5.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `final inventory management system`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_part`
--

CREATE TABLE IF NOT EXISTS `category_part` (
  `part_id` varchar(10) NOT NULL,
  `category_id` varchar(10) NOT NULL,
  `del_status` int(1) NOT NULL,
  PRIMARY KEY (`part_id`,`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category_part_supplier`
--

CREATE TABLE IF NOT EXISTS `category_part_supplier` (
  `category_id` int(100) NOT NULL,
  `part_id` int(100) NOT NULL,
  `supplier_id` int(100) NOT NULL,
  `cost_price` decimal(10,2) NOT NULL,
  `cps_id` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`cps_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `category_part_supplier`
--

INSERT INTO `category_part_supplier` (`category_id`, `part_id`, `supplier_id`, `cost_price`, `cps_id`) VALUES
(1, 1, 1, '10.30', 1),
(1, 2, 1, '30.00', 2),
(2, 3, 1, '20.10', 3),
(2, 7, 2, '45.20', 4),
(3, 8, 4, '90.21', 5),
(4, 11, 4, '52.12', 6),
(5, 12, 5, '62.12', 7),
(1, 10, 4, '32.12', 8),
(1, 7, 3, '32.12', 9),
(9, 5, 3, '20.30', 10),
(8, 6, 2, '32.12', 11),
(9, 4, 2, '10.00', 12),
(3, 4, 1, '15.00', 13);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `contact_no1` int(8) NOT NULL,
  `contact_no2` int(8) NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `address_line1` varchar(100) NOT NULL,
  `address_line2` varchar(100) NOT NULL,
  `address_line3` varchar(100) NOT NULL,
  `date_of_birth` datetime NOT NULL,
  `date_of_creation` datetime NOT NULL,
  `last_modified` datetime NOT NULL,
  `del_status` int(1) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `created_by` varchar(10) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `first_name`, `last_name`, `contact_no1`, `contact_no2`, `email_address`, `gender`, `address_line1`, `address_line2`, `address_line3`, `date_of_birth`, `date_of_creation`, `last_modified`, `del_status`, `remark`, `created_by`) VALUES
(1, 'Jacob', 'Tan            ', 91234567, 94536172, 'jacobtan@hotmail.cpm', 'M', 'Fajar Road 3 Blk 235', '#06-52', 'S534202', '1991-12-17 00:00:00', '2014-12-01 00:00:00', '2014-12-09 18:00:52', 0, 'too cool to be true!', 'U01'),
(2, 'Joshua', 'Tan', 91246758, 95674382, 'joshua_tan@hotmail.com', 'M', 'Upper Bukit Timah Blk 324', '#05-234', 'S563245', '2014-10-13 00:00:00', '2015-01-07 00:00:00', '2015-01-07 00:00:00', 0, 'You lost the game!', 'U01'),
(3, 'Eunice', 'Ng', 94567123, 94325675, 'euniceng@hotmail.com', 'F', 'Upper Thomson Road Blk 231', '#04-23', 'S543567', '1980-01-04 00:00:00', '2015-01-07 00:00:00', '2015-01-07 00:00:00', 0, 'I am a nice lady!', 'U01');

-- --------------------------------------------------------

--
-- Table structure for table `customer_invoice`
--

CREATE TABLE IF NOT EXISTS `customer_invoice` (
  `invoice_no` int(100) NOT NULL AUTO_INCREMENT,
  `invoice_date` date NOT NULL,
  `gst` decimal(3,2) NOT NULL,
  `total_amt_charged` decimal(10,2) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `deposit` decimal(10,2) NOT NULL,
  `del_status` int(1) NOT NULL,
  `payment_status` varchar(30) NOT NULL,
  `customer_id` varchar(10) NOT NULL,
  `quotation_no` varchar(10) NOT NULL,
  PRIMARY KEY (`invoice_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=458 ;

--
-- Dumping data for table `customer_invoice`
--

INSERT INTO `customer_invoice` (`invoice_no`, `invoice_date`, `gst`, `total_amt_charged`, `remark`, `deposit`, `del_status`, `payment_status`, `customer_id`, `quotation_no`) VALUES
(123, '2015-02-06', '9.99', '212.00', 'asd', '0.00', 0, 'false', '4', '123'),
(456, '2015-02-23', '9.99', '123.00', '', '0.00', 0, 'PAID', '2', '123123'),
(457, '2015-02-23', '8.93', '148.76', '', '0.00', 0, 'PAID', '2', '55563');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_item`
--

CREATE TABLE IF NOT EXISTS `invoice_item` (
  `invitem_id` int(20) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(20) NOT NULL,
  `part_id` int(10) NOT NULL,
  `price_charged` decimal(10,2) NOT NULL,
  `del_status` int(1) NOT NULL,
  PRIMARY KEY (`invitem_id`,`invoice_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `invoice_item`
--

INSERT INTO `invoice_item` (`invitem_id`, `invoice_no`, `part_id`, `price_charged`, `del_status`) VALUES
(1, '123', 2, '200.00', 0),
(3, '12', 12, '12.00', 0),
(4, 'asd', 123, '123.00', 0),
(5, 'INV22021500', 4, '20.30', 0),
(6, 'INV22021500', 9, '64.23', 0);

-- --------------------------------------------------------

--
-- Table structure for table `part`
--

CREATE TABLE IF NOT EXISTS `part` (
  `part_id` int(10) NOT NULL AUTO_INCREMENT,
  `part_no` varchar(50) NOT NULL,
  `part_name` varchar(50) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `part_descrp` varchar(30000) NOT NULL,
  `part_qty` int(10) NOT NULL,
  `retail_price` decimal(10,2) NOT NULL,
  `del_status` int(1) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `stock_lvl_por` int(10) NOT NULL,
  `stock_status` varchar(40) NOT NULL,
  `service_id` int(10) NOT NULL,
  PRIMARY KEY (`part_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `part`
--

INSERT INTO `part` (`part_id`, `part_no`, `part_name`, `brand`, `part_descrp`, `part_qty`, `retail_price`, `del_status`, `remark`, `stock_lvl_por`, `stock_status`, `service_id`) VALUES
(1, 'T-01234', 'Tyre', 'TVS Tyre', 'Car Tyre', 2, '20.40', 0, 'Fine quality tyre', 10, 'Adequate Stock Supply', 2),
(2, 'T-03456', 'Tyre', 'TigerAir', 'Fine Quality Tyre', 78, '50.30', 0, 'Nice!', 50, 'Adequate Stock Supply', 2),
(3, 'T-05432', 'Tyre', 'Stamford ', '', 3, '40.20', 0, 'nil', 20, 'Adequate Stock Supply', 2),
(4, 'B-01324', 'Battery', ' Amoron batter ', 'The Amoron batteries looked stunning, offered complete peace of mind with zero-maintenance and offered the longest warranty that the Indian market had ever seen.', 65, '20.30', 0, 'nil', 50, 'Adequate Stock Supply', 4),
(5, 'B-03425', 'Battery', 'AGM ', '', 44, '20.90', 0, 'nil', 20, 'Adequate Stock Supply', 4),
(6, 'O-02341', 'Motor Lubricant Oil', 'Castrol', 'Fine quality oil', 78, '30.20', 0, '', 20, 'Adequate Stock Supply', 1),
(7, 'T-01254', 'Tyre', 'Bridgestone Potenza RE050A', 'The Bridgestone Potenza RE050A is a Max Performance Summer tyre designed to be fitted to Passenger Cars.', 8, '98.30', 0, 'nil', 50, 'Insufficient', 2),
(8, 'T-14328', 'Tyre', ' Bridgestone Turanza ER300', 'Bridgestone tyres, Passenger Car Summer Premium Touring tyres\r\nThe Bridgestone Turanza ER300 is a Premium Touring Summer tyre designed to be fitted to Passenger Cars. ', 28, '123.21', 0, 'nil', 110, 'Insufficient Supply', 2),
(9, 'T-12425', 'Tyre', 'Barum Bravuris 2', 'The Barum Bravuris 2 is a High Performance Summer tyre designed to be fitted to Passenger Cars. Below is data from 112 tyre reviews averaging 80% over 1,249,581 miles driven.\r\n', 6, '32.12', 0, 'nil', 23, 'Insufficient Supply', 2),
(10, 'T-2043', 'Tyre', 'Pirelli P6000', 'The Pirelli P6000 is a Premium Touring Summer tyre designed to be fitted to Passenger Cars. Below is data from 158 tyre reviews averaging 55% over 2,293,982 miles driven. ', 43, '43.12', 0, 'nil', 60, 'Insufficient Supply', 2),
(11, 'T-9243', 'Tyre', 'Continental Sport Contact 2', 'The Continental Sport Contact 2 is a Max Performance Summer tyre designed to be fitted to Passenger Cars. ', 60, '89.20', 0, 'nil', 70, 'Sufficient', 2),
(12, 'T-5432', 'Tyre', 'Firestone TZ200', 'The Firestone TZ200 is a High Performance Summer tyre designed to be fitted to Passenger Cars. ', 30, '72.12', 0, 'Nil', 90, 'Insufficient Supply', 2);

-- --------------------------------------------------------

--
-- Table structure for table `po_item`
--

CREATE TABLE IF NOT EXISTS `po_item` (
  `po_no` int(11) NOT NULL,
  `po_item_no` int(200) NOT NULL AUTO_INCREMENT,
  `part_order_qty` int(11) NOT NULL,
  `cost_price_chrged` decimal(10,2) NOT NULL,
  `part_no` varchar(200) NOT NULL,
  `del_status` int(1) NOT NULL,
  PRIMARY KEY (`po_no`,`po_item_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `po_item`
--

INSERT INTO `po_item` (`po_no`, `po_item_no`, `part_order_qty`, `cost_price_chrged`, `part_no`, `del_status`) VALUES
(10, 1, 1, '123.00', '5', 0),
(9, 1, 1, '123.00', '6', 0),
(8, 1, 1, '123.00', '5', 0),
(10, 2, 1, '123.00', '6', 0),
(11, 1, 1, '123.00', '2', 0),
(11, 2, 1, '150.00', '3', 0),
(15, 1, 1, '123.00', 'O-02341', 0),
(16, 1, 1, '123.00', 'O-02341', 0),
(17, 1, 21, '1160.19', 'T-9243', 0),
(18, 1, 10, '150.00', 'T-01234', 0),
(18, 2, 1, '123.00', 'T-03456', 0),
(19, 1, 30, '150.00', 'T-01234', 0),
(21, 1, 32, '508.80', 'B-01324', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

CREATE TABLE IF NOT EXISTS `purchase_order` (
  `po_no` int(200) NOT NULL AUTO_INCREMENT,
  `date_of_creation` date NOT NULL,
  `date_of_issue` date NOT NULL,
  `po_status` varchar(30) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `del_status` int(1) NOT NULL,
  `ordered_by` varchar(10) NOT NULL,
  `supplier_id` int(200) NOT NULL,
  PRIMARY KEY (`po_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `purchase_order`
--

INSERT INTO `purchase_order` (`po_no`, `date_of_creation`, `date_of_issue`, `po_status`, `remark`, `del_status`, `ordered_by`, `supplier_id`) VALUES
(8, '2015-02-09', '2015-02-09', 'Goods Received', '', 0, 'Lee Chern ', 1),
(9, '2015-02-09', '2015-02-09', 'Goods Received', '', 0, 'Lee Chern ', 1),
(10, '2015-02-10', '2015-02-10', 'Goods Received', '', 0, 'Lee Chern ', 1),
(11, '2015-02-10', '2015-02-10', 'Goods Received', '', 0, 'Lee Chern ', 1),
(12, '2015-02-12', '2015-02-12', 'Sent', '', 0, 'asd', 1),
(13, '2015-02-12', '2015-02-12', 'Sent', '', 0, 'asd', 1),
(14, '2015-02-12', '2015-02-12', 'Sent', '', 0, 'asd', 1),
(15, '2015-02-12', '2015-02-12', 'Sent', '', 0, 'asd', 1),
(16, '2015-02-12', '2015-02-12', 'Sent', '', 0, 'asd', 1),
(17, '2015-02-13', '0000-00-00', 'Goods Received', 'Would consider reordering purchase order.', 0, 'Lee Chern ', 4),
(18, '2015-02-13', '2015-02-13', 'Sent', 'dwqe', 0, 'ewq', 1),
(19, '2015-02-13', '2015-02-13', 'Sent', 'nil', 0, 'Hong Liang', 1),
(20, '2015-02-13', '0000-00-00', 'sent', 'ds', 0, 'Lee Chern ', 1),
(21, '2015-02-13', '0000-00-00', 'sent', 'ds', 0, 'Lee Chern ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `quotation`
--

CREATE TABLE IF NOT EXISTS `quotation` (
  `quotation_no` int(10) NOT NULL AUTO_INCREMENT,
  `quotation_date` datetime NOT NULL,
  `total_amt_charged` decimal(10,2) NOT NULL,
  `gst` decimal(3,2) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `del_status` int(11) NOT NULL,
  `plate_no` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`quotation_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55565 ;

--
-- Dumping data for table `quotation`
--

INSERT INTO `quotation` (`quotation_no`, `quotation_date`, `total_amt_charged`, `gst`, `remark`, `del_status`, `plate_no`, `customer_id`) VALUES
(11111, '0000-00-00 00:00:00', '254.50', '0.00', '', 0, 'JFU1808', 0),
(22222, '2015-01-23 16:26:15', '445.50', '0.04', '', 0, 'JFU1808', 0),
(33333, '2015-01-23 16:29:25', '678.90', '0.04', '', 0, 'JFU1808', 0),
(44444, '2015-01-23 16:30:45', '678.90', '0.04', '', 0, 'JFU1808', 0),
(55555, '2015-01-23 16:31:25', '1098.50', '0.04', '', 0, 'JFU1808', 0),
(6, '2015-01-23 16:33:11', '445.50', '0.04', '', 0, '0', 0),
(7, '2015-01-23 16:36:03', '445.50', '0.04', '', 0, '0', 0),
(8, '2015-01-23 16:36:30', '445.50', '0.04', '', 0, '0', 0),
(9, '2015-01-23 16:39:08', '678.90', '0.04', '', 0, '0', 0),
(10, '2015-01-23 16:44:07', '1673.90', '0.04', '', 0, '0', 0),
(11, '2015-01-23 16:46:24', '2249.40', '0.04', '', 1, '0', 0),
(12, '2015-01-23 16:49:20', '1098.50', '0.04', '', 0, '0', 0),
(13, '2015-01-23 17:11:34', '954.70', '0.04', '', 0, '0', 0),
(14, '2015-01-23 17:15:28', '627.70', '0.04', '', 0, '0', 0),
(15, '2015-01-23 17:20:56', '678.90', '0.04', '', 0, '0', 0),
(16, '2015-01-23 17:23:11', '678.90', '0.04', '', 0, '0', 0),
(17, '2015-01-23 17:23:45', '445.50', '0.04', '', 0, '0', 0),
(18, '2015-01-23 17:23:48', '445.50', '0.04', '', 0, '0', 0),
(19, '2015-01-23 17:24:06', '1673.90', '0.04', '', 0, '0', 0),
(20, '2015-01-23 17:24:31', '1673.90', '0.04', '', 0, '0', 0),
(21, '2015-01-23 17:29:38', '254.50', '0.04', '', 0, '0', 0),
(22, '2015-01-23 17:34:36', '678.90', '0.04', '', 0, '0', 0),
(23, '2015-01-23 18:13:29', '42.40', '0.04', '', 0, '0', 0),
(24, '2015-01-23 18:16:56', '42.40', '0.04', '', 0, '0', 0),
(25, '2015-01-23 18:20:22', '445.50', '0.04', '', 0, '0', 0),
(26, '2015-01-23 18:20:34', '445.50', '0.04', '', 0, '0', 0),
(27, '2015-01-23 18:22:42', '21.20', '0.04', '', 0, '0', 0),
(28, '2015-01-23 18:22:45', '21.20', '0.04', '', 0, '0', 0),
(29, '2015-01-23 18:23:27', '42.40', '0.04', '', 0, '0', 0),
(30, '2015-01-23 18:24:06', '21.20', '0.04', '', 0, '0', 0),
(31, '2015-01-23 18:24:24', '21.20', '0.04', '', 0, '0', 0),
(32, '2015-01-23 18:27:22', '21.20', '0.04', '', 0, '0', 0),
(33, '2015-01-23 18:30:18', '21.20', '0.04', '', 0, '0', 0),
(34, '2015-01-23 18:34:26', '254.50', '0.04', '', 0, '0', 0),
(35, '2015-01-23 18:36:18', '254.50', '0.04', '', 0, '0', 0),
(36, '2015-01-23 18:37:12', '254.50', '0.04', '', 0, '0', 0),
(37, '2015-01-23 18:45:27', '0.00', '0.04', '', 0, '0', 0),
(38, '2015-01-23 18:45:55', '21.20', '0.04', '', 0, '0', 0),
(39, '2015-01-23 18:58:08', '42.40', '0.04', '', 0, '0', 0),
(40, '2015-01-23 18:58:31', '21.20', '0.04', '', 0, '0', 0),
(41, '2015-01-23 18:58:46', '21.20', '0.04', '', 0, '0', 0),
(42, '2015-01-23 19:02:04', '0.00', '0.04', '', 0, '0', 0),
(43, '2015-01-23 19:02:34', '0.00', '0.04', '', 0, '0', 0),
(44, '2015-01-23 19:02:52', '73.50', '0.04', '', 0, '0', 0),
(45, '2015-01-23 19:02:52', '73.50', '0.04', '', 0, '0', 0),
(46, '2015-01-23 19:03:29', '0.00', '0.04', '', 0, '0', 0),
(47, '2015-01-23 19:03:55', '0.00', '0.04', '', 0, '0', 0),
(48, '2015-01-23 19:04:30', '21.20', '0.04', '', 0, '0', 0),
(49, '2015-01-27 21:16:35', '43.03', '0.06', '', 0, '1', 0),
(50, '2015-01-27 21:20:37', '22.15', '0.06', '', 0, '1', 0),
(51, '2015-01-27 21:23:08', '42.61', '0.06', '', 0, '1', 0),
(52, '2015-01-27 21:27:33', '53.31', '0.06', '', 0, '1', 0),
(53, '2015-01-27 21:28:37', '106.63', '0.06', '', 0, '1', 0),
(54, '2015-01-27 21:28:37', '106.63', '0.06', '', 0, '1', 0),
(55, '2015-01-27 21:30:23', '21.51', '0.06', '', 0, '1', 0),
(56, '2015-01-27 21:31:25', '32.01', '0.06', '', 0, '1', 0),
(57, '2015-01-27 21:33:28', '42.61', '0.06', '', 0, '1', 0),
(58, '2015-01-27 21:36:54', '32.01', '0.06', '', 0, '1', 0),
(59, '2015-01-27 21:37:32', '32.01', '0.06', '', 0, '1', 0),
(60, '2015-01-27 23:19:09', '21.61', '0.06', '', 0, '1', 0),
(61, '2015-01-27 23:19:38', '32.01', '0.06', '', 0, '1', 0),
(62, '2015-01-27 23:21:13', '32.01', '0.06', '', 0, '1', 0),
(63, '2015-01-27 23:21:38', '32.01', '0.06', '', 0, '1', 0),
(64, '2015-01-27 23:22:16', '32.01', '0.06', '', 0, '1', 0),
(65, '2015-01-27 23:24:03', '22.15', '0.06', '', 0, '1', 0),
(66, '2015-01-27 23:24:33', '22.15', '0.06', '', 0, '1', 0),
(67, '2015-01-27 23:26:56', '53.31', '0.06', '', 0, '1', 0),
(68, '2015-01-27 23:30:21', '32.01', '0.06', '', 0, '1', 0),
(69, '2015-01-27 23:33:24', '32.01', '0.06', '', 0, '1', 0),
(70, '2015-01-27 23:35:28', '21.51', '0.06', '', 0, '1', 0),
(71, '2015-01-27 23:35:58', '149.76', '0.06', '', 0, '1', 0),
(72, '2015-01-27 23:35:59', '149.76', '0.06', '', 0, '1', 0),
(73, '2015-01-27 23:36:01', '149.76', '0.06', '', 0, '1', 0),
(74, '2015-01-27 23:37:54', '149.76', '0.06', '', 0, '1', 0),
(75, '2015-01-27 23:37:55', '149.76', '0.06', '', 0, '1', 0),
(76, '2015-01-27 23:37:56', '149.76', '0.06', '', 0, '1', 0),
(77, '2015-01-27 23:38:32', '21.61', '0.06', '', 0, '1', 0),
(55556, '2015-02-12 21:51:34', '42.61', '0.06', '', 0, 'SBA1234A', 1),
(55557, '2015-02-13 01:48:28', '32.01', '0.06', '', 0, 'JFU1808', 4),
(1, '0000-00-00 00:00:00', '254.50', '0.00', '', 0, '', 0),
(2, '2015-01-23 16:26:15', '445.50', '0.04', '', 0, '', 0),
(3, '2015-01-23 16:29:25', '678.90', '0.04', '', 0, '', 0),
(4, '2015-01-23 16:30:45', '678.90', '0.04', '', 0, '', 0),
(5, '2015-01-23 16:31:25', '1098.50', '0.04', '', 0, '', 0),
(55558, '2015-02-13 07:12:37', '106.63', '0.06', '', 0, 'SBA1234A', 1),
(55559, '2015-02-13 07:15:44', '32.01', '0.06', '', 0, 'SBA1234A', 1),
(55560, '2015-02-13 07:17:06', '44.30', '0.06', '', 0, 'SBA1234A', 1),
(55561, '2015-02-13 07:18:14', '45.70', '0.06', '', 0, 'SBA1234A', 1),
(55562, '2015-02-13 07:22:35', '42.61', '0.06', '', 0, 'SBA1234A', 1),
(55563, '2015-02-13 07:25:55', '89.60', '0.06', '', 0, 'SVX1423', 2),
(55564, '2015-02-13 11:27:54', '42.61', '0.06', '', 0, 'SBA1234A', 1);

-- --------------------------------------------------------

--
-- Table structure for table `quotation_item`
--

CREATE TABLE IF NOT EXISTS `quotation_item` (
  `item_no` int(20) NOT NULL,
  `quotation_no` int(10) NOT NULL,
  `service_id` int(10) NOT NULL,
  `service_name` varchar(50) NOT NULL,
  `part_id` int(10) NOT NULL,
  `part_no` varchar(50) NOT NULL,
  `price_charged` decimal(10,2) NOT NULL,
  `del_status` int(1) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`item_no`,`quotation_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quotation_item`
--

INSERT INTO `quotation_item` (`item_no`, `quotation_no`, `service_id`, `service_name`, `part_id`, `part_no`, `price_charged`, `del_status`, `qty`) VALUES
(0, 0, 2, 'Tyre Service', 1, 'T-01234', '428.40', 0, 0),
(2, 0, 4, 'Battery Service', 4, 'B-01324', '60.00', 0, 0),
(3, 0, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 0),
(1, 0, 2, 'Tyre Service', 1, 'T-01234', '428.40', 0, 0),
(1, 17, 2, 'Tyre Service', 1, 'T-01234', '428.40', 0, 0),
(1, 48, 2, 'Tyre Service', 1, 'T-01234', '20.40', 0, 0),
(1, 51, 2, 'Tyre Service', 2, 'T-03456', '50.30', 0, 1),
(2, 53, 2, 'Tyre Service', 2, 'T-03456', '50.30', 0, 1),
(1, 55, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 1),
(1, 56, 2, 'Tyre Service', 3, 'T-05432', '40.20', 0, 1),
(1, 58, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 1),
(1, 59, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 60, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 1),
(1, 61, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 1),
(1, 63, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 1),
(1, 65, 4, 'Battery Service', 5, 'B-03425', '20.90', 0, 1),
(1, 66, 4, 'Battery Service', 5, 'B-03425', '20.90', 0, 1),
(1, 67, 2, 'Tyre Service', 2, 'T-03456', '50.30', 0, 1),
(1, 68, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 1),
(1, 69, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 1),
(1, 70, 4, 'Battery Service', 4, 'B-01324', '20.30', 0, 1),
(2, 71, 4, 'Battery Service', 4, 'B-01324', '20.30', 0, 1),
(3, 72, 2, 'Tyre Service', 2, 'T-03456', '100.60', 0, 2),
(3, 73, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(3, 75, 4, 'Tyre Service', 4, 'T-03456', '100.60', 0, 2),
(3, 76, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 77, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 78, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 79, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 80, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 81, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 82, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 83, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 84, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 85, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 86, 2, 'Tyre Service', 1, 'T-01234', '40.79', 0, 2),
(1, 87, 2, 'Tyre Service', 1, 'T-01234', '40.79', 0, 0),
(1, 88, 2, 'Tyre Service', 3, 'T-05432', '0.00', 0, 0),
(1, 89, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 90, 2, 'Tyre Service', 1, 'T-01234', '652.79', 0, 32),
(1, 91, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 92, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 93, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 94, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 95, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 96, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 97, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 98, 2, 'Tyre Service', 1, 'T-01234', '61.20', 0, 3),
(1, 99, 2, 'Tyre Service', 1, 'T-01234', '61.20', 0, 0),
(1, 100, 2, 'Tyre Service', 1, 'T-01234', '61.20', 0, 1),
(1, 101, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 0),
(1, 102, 2, 'Tyre Service', 2, 'T-03456', '0.00', 0, 0),
(1, 103, 2, 'Tyre Service', 2, 'T-03456', '100.60', 0, 2),
(2, 105, 2, 'Tyre Service', 9, 'T-12425', '64.23', 0, 2),
(2, 106, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(2, 107, 2, 'Tyre Service', 2, 'T-03456', '100.60', 0, 2),
(2, 108, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(3, 110, 2, 'Tyre Service', 2, 'T-03456', '100.60', 0, 2),
(1, 111, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 112, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 113, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 114, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 115, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 116, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 117, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(1, 118, 2, 'Tyre Service', 1, 'T-01234', '40.79', 0, 2),
(2, 119, 2, 'Tyre Service', 11, 'T-9243', '178.40', 0, 2),
(2, 120, 2, 'Tyre Service', 1, 'T-01234', '20.39', 0, 1),
(2, 121, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 1),
(2, 122, 2, 'Tyre Service', 1, 'T-05432', '40.20', 0, 1),
(2, 125, 2, 'Tyre Service', 1, 'T-01234', '40.79', 0, 2),
(2, 126, 2, 'Tyre Service', 2, 'T-03456', '50.30', 0, 1),
(1, 127, 2, 'Tyre Service', 7, 'T-01254', '196.60', 0, 2),
(2, 127, 2, 'Tyre Service', 3, 'T-05432', '40.20', 0, 1),
(1, 128, 4, 'Battery Service', 4, 'B-01324', '40.60', 0, 2),
(2, 128, 2, 'Tyre Service', 9, 'T-12425', '32.11', 0, 1),
(1, 129, 2, 'Tyre Service', 2, 'T-03456', '50.30', 0, 1),
(1, 130, 2, 'Battery Service', 2, 'B-01324', '40.60', 0, 2),
(2, 130, 2, 'Tyre Service', 2, 'T-12425', '32.11', 0, 1),
(1, 131, 1, 'Oil Change Service', 6, 'O-02341', '30.20', 0, 1),
(2, 131, 2, 'Tyre Service', 10, 'T-2043', '86.24', 0, 2),
(1, 132, 2, 'Tyre Service', 10, 'T-2043', '43.12', 0, 1),
(2, 132, 2, 'Tyre Service', 11, 'T-9243', '178.40', 0, 2),
(1, 136, 2, 'Tyre Service', 1, 'T-01234', '61.20', 0, 3),
(1, 137, 2, 'Tyre Service', 8, 'T-14328', '123.21', 0, 1),
(1, 138, 4, 'Battery Service', 4, 'B-01324', '40.60', 0, 2),
(1, 139, 2, 'Tyre Service', 9, 'T-12425', '64.23', 0, 2),
(1, 140, 2, 'Tyre Service', 8, 'T-14328', '123.21', 0, 1),
(1, 141, 2, 'Tyre Service', 3, 'T-05432', '844.20', 0, 21),
(1, 142, 4, 'Battery Service', 4, 'B-01324', '40.60', 0, 2),
(1, 143, 4, 'Battery Service', 4, 'B-01324', '0.00', 0, 0),
(1, 144, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 145, 4, 'Battery Service', 5, 'B-03425', '0.00', 0, 0),
(1, 146, 4, 'Battery Service', 5, 'B-03425', '0.00', 0, 0),
(1, 147, 2, 'Tyre Service', 1, 'T-01234', '0.00', 0, 0),
(1, 55562, 2, 'Tyre Service', 3, 'T-05432', '40.20', 0, 1),
(1, 55563, 4, 'Battery Service', 4, 'B-01324', '20.30', 0, 1),
(2, 55563, 2, 'Tyre Service', 9, 'T-12425', '64.23', 0, 2),
(1, 55564, 2, 'Tyre Service', 8, 'T-05432', '40.20', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE IF NOT EXISTS `service` (
  `service_id` varchar(10) NOT NULL,
  `service_name` mediumtext NOT NULL,
  `service_dscrp` varchar(200) NOT NULL,
  `service_price` decimal(10,2) NOT NULL,
  `del_status` int(1) NOT NULL,
  `remark` varchar(500) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_id`, `service_name`, `service_dscrp`, `service_price`, `del_status`, `remark`) VALUES
('1', 'Oil Change Service', 'The change of fine quality Castrol fuel that can help to save vehicle fuel consumption', '15.30', 0, 'Fuel price is calculated based on the volume top-up.'),
('2', 'Tyre Service', 'Lian Huat has over twenty years experience in tyre technology. Our experience allows us to increase security, longevity, comfort and attention to the customised tyre that we provide.\r\n', '54.30', 0, 'nil'),
('3', 'Vehicle Maintenence', 'Lian Huat provides inspecting on the condition of car subsystems (e.g., engine) and servicing or replacing parts and fluids.               ', '32.10', 0, 'nil'),
('4', 'Battery Service', 'Lian Huat provides several diagnostic test which includes visually inspecting the battery using test equipment to check cranking amp1 capacity of the battery and much more.', '30.20', 0, 'nil'),
('5', 'Clutch Brake Service', 'Lian Huat offers a complete line of standard wrap spring clutches and clutch/brakes, available for immediate delivery through our network of distributors.', '0.00', 0, 'nil'),
('6', 'Suspension Service', 'Our technicians are specialists in all things steering and suspension.Our service ensures fine tuning of suspension in car wheels to prevent  deterioration of handling and accelerated of tire wear. ', '60.20', 0, 'nil'),
('7', 'Brake Service', 'Our technicians are experts in servicing the computer-controlled components of the anti-lock braking systems (ABS) that are common on today’s vehicles.\r\n', '50.60', 0, 'nil'),
('8', 'Tuning and Diagnostic Service', 'Lian Huat pride itself in its rich and long knowledge and experience in Tuning & Diagnostic Service. ', '21.30', 0, 'nil');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `supplier_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `office_contact` int(8) NOT NULL,
  `hp_contact` int(8) NOT NULL,
  `fax_contact` int(8) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `address_line1` varchar(100) NOT NULL,
  `address_line2` varchar(100) NOT NULL,
  `address_line3` varchar(100) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `del_status` int(1) NOT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `first_name`, `last_name`, `office_contact`, `hp_contact`, `fax_contact`, `company_name`, `address_line1`, `address_line2`, `address_line3`, `remark`, `del_status`) VALUES
(1, 'Junie', 'Tan', 67231053, 92341245, 612534678, 'BeforeMarket Ptd Ltd', 'Bukit Panjang street 4,Blk 42', '#06-21', 'S563274', 'nil.', 0),
(2, 'Tonny ', 'Tan', 61234567, 91234567, 61237586, 'AfterShore Pte Ltd', 'Bukit Timah street 5,Blk213', '#02-12', 'S512349', 'Lowest price offered for automobile part in the region.', 0),
(3, 'Emily', 'Fisher', 61234598, 91230345, 61294857, 'Kauffman Motor Vehicle Company', 'Queenway street 12,Blk123', '#03-12', 'S542341', 'Precious supplier', 0),
(4, 'Derek', 'Lim', 61237123, 91205432, 61204321, 'Henderson Vehicle Company ', 'Woodlands Drive 32', 'Blk194', '#05-12', 'nil', 0),
(5, 'Jackie', 'Loh', 61284345, 91204567, 67348576, 'HaoWei Pte Ltd', 'Toh Tuck Drive 123', 'Blk12', '#01-12', 'nil', 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_part`
--

CREATE TABLE IF NOT EXISTS `supplier_part` (
  `supplier_id` int(200) NOT NULL,
  `part_id` int(11) NOT NULL AUTO_INCREMENT,
  `cost_price` decimal(10,2) NOT NULL,
  `dek_status` int(1) NOT NULL,
  PRIMARY KEY (`supplier_id`,`part_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `supplier_part`
--

INSERT INTO `supplier_part` (`supplier_id`, `part_id`, `cost_price`, `dek_status`) VALUES
(1, 1, '150.00', 0),
(1, 2, '123.00', 0),
(1, 3, '150.00', 0),
(1, 4, '123.00', 0),
(1, 5, '123.00', 0),
(1, 6, '123.00', 0),
(0, 1, '0.00', 0),
(1, 13, '32.00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userid` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `accesslevel` varchar(1) NOT NULL,
  `dateofcreation` date NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `job_role` varchar(50) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `name`, `contact`, `accesslevel`, `dateofcreation`, `remarks`, `job_role`) VALUES
(7, 'abc', 'asd123', 'sdas', '92345', '1', '0000-00-00', '', ''),
(6, 'abc', 'asd123', 'sdas', '92345', '1', '0000-00-00', '', ''),
(5, 'hello', 'hello', 'hello', 'hello', 'h', '0000-00-00', '', ''),
(27, 'administrator99', 'liA5UjgyY2Ypk', 'Chern Chow', '0123456', '1', '2015-02-19', '', 'Administrator'),
(12, 'Bestmaster99', 'liZjdkwAeUZoo', 'Tchea JiaWei', '91234567', '2', '2015-02-18', '', ''),
(19, 'vannylim', 'liD9qG.4Rmvo2', 'Vanessa Win', '96543234', '2', '2015-02-19', '', 'Director'),
(18, 'vannylim', 'liD9qG.4Rmvo2', 'Vanessa Win', '96543234', '2', '2015-02-19', '', 'Director'),
(26, 'jaguar1234', 'liaQz2pF6sjA2', 'fdgsafg', '965432345', '4', '2015-02-19', '', 'Mechanic'),
(25, 'dfgrsd1245', 'liD9qG.4Rmvo2', 'thyhtrgefw', '87654324', '2', '2015-02-19', '', 'Director'),
(24, 'fdsfijet1234', 'liD9qG.4Rmvo2', 'ertgds', '95432123', '2', '2015-02-19', '', 'Director'),
(28, 'admin', 'liZh82GeUpgxs', 'Chern Chow', '86662713', '1', '2015-02-21', '', ''),
(29, 'asdasdasd', 'liRhlUJmCp0uU', 'asdasd', '12345678', '1', '2015-02-21', '', 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE IF NOT EXISTS `vehicle` (
  `vehicle_id` int(10) NOT NULL AUTO_INCREMENT,
  `plate_no` varchar(50) NOT NULL,
  `del_status` int(1) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `category_id` int(10) NOT NULL,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`vehicle_id`, `plate_no`, `del_status`, `customer_id`, `category_id`) VALUES
(1, 'SBA1234A', 0, 1, 1),
(2, 'SVX1423', 0, 2, 2),
(3, 'SBI1468', 0, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_category`
--

CREATE TABLE IF NOT EXISTS `vehicle_category` (
  `category_id` int(10) NOT NULL AUTO_INCREMENT,
  `model` varchar(50) NOT NULL,
  `make` varchar(50) NOT NULL,
  `del_status` int(1) NOT NULL,
  `remark` varchar(500) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `vehicle_category`
--

INSERT INTO `vehicle_category` (`category_id`, `model`, `make`, `del_status`, `remark`) VALUES
(1, 'RAV4', 'Toyota', 0, 'Superb type of car!'),
(2, 'Arnage', 'Bentley', 0, 'nil'),
(3, 'Aveo ', 'Chevrolet', 0, 'nil'),
(4, 'D89', 'Aston Martin', 0, 'nil'),
(5, 'DBS', 'Aston Martin', 0, 'nil'),
(6, 'V8', 'Aston Martin', 0, 'nil'),
(7, 'Continental', 'Bentley', 0, 'nil'),
(8, 'Accord', 'Honda', 0, 'nil'),
(9, 'Compass', 'Jeep', 0, 'nil'),
(10, 'Rover', '216', 0, 'nil');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
